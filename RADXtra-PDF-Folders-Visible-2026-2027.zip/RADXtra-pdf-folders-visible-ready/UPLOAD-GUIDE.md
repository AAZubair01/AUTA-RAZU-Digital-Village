# RADXtra PDF Upload Guide

This package uses visible PDF holder files so the PDF folders appear clearly in GitHub.

Git does not preserve empty folders. For that reason, every PDF upload folder contains a visible file named:

```text
UPLOAD-PDFS-HERE.txt
```

Do not delete this file until you have uploaded at least one PDF into the same folder.

## Correct upload pattern

The slash `/` is only a folder separator. It is not part of the PDF filename.

Example full path:

```text
level2/pdfs/auta-razu/rad-201-session-1.pdf
```

Folder:

```text
level2/pdfs/auta-razu/
```

PDF filename:

```text
rad-201-session-1.pdf
```

## AUTA-RAZU active course upload paths

### Level 2 — RAD-201 Radiation Physics

Upload into:

```text
level2/pdfs/auta-razu/
```

Filenames:

```text
rad-201-session-1.pdf
rad-201-session-2.pdf
rad-201-session-3.pdf
rad-201-session-4.pdf
rad-201-session-5.pdf
```

### Level 4 — RAD-423 Imaging Informatics

Upload into:

```text
level4/pdfs/auta-razu/
```

Filenames:

```text
rad-423-session-1.pdf
rad-423-session-2.pdf
rad-423-session-3.pdf
rad-423-session-4.pdf
rad-423-session-5.pdf
```

### Level 4 — RAD-447 Radionuclide Imaging / Nuclear Medicine

Upload into:

```text
level4/pdfs/auta-razu/
```

Filenames:

```text
rad-447-session-1.pdf
rad-447-session-2.pdf
rad-447-session-3.pdf
rad-447-session-4.pdf
rad-447-session-5.pdf
```

### Level 5 — RAD-541 Magnetic Resonance Imaging II

Upload into:

```text
level5/pdfs/auta-razu/
```

Filenames:

```text
rad-541-session-1.pdf
rad-541-session-2.pdf
rad-541-session-3.pdf
rad-541-session-4.pdf
rad-541-session-5.pdf
```

## After upload

Commit the uploaded PDF files to GitHub. The matching Open PDF buttons in the lecturer workspace will work automatically if the filename matches exactly.
